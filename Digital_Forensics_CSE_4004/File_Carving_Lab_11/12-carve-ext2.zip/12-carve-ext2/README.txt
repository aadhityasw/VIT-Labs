
                       Test 12 - Basic Data Carving #2
                                 Mar 2005

                            http://dftt.sf.net
			        Nick Mikus

---------------------------------------------------------------------------
These are test images for testing digital forensic analysis tools.
Import them into the tool of your choice and determine which files
are shown.  The contents of each image can be found in index.html.

This image is released under the terms of the GNU General Public
License as published by the Free Software Foundation.  It is included
in the COPYING file.

Nick Mikus
nick.mikus@gmail.com
